Tejas Kamtam
305749402

# A Kernel Seedling

One sentence description:

A kernel module that creates a file /proc/count that contains the number of current processes running.

## Building

Explain how to build your kernel module

1. Ensure you have a clean working repository ( run 'make clean' if needed)
2. Run 'make'
3. Ensure no errors ('proc_count.ko' should be created)

## Running

Explain how to run your kernel module and what to expect

1. Add the module (run 'insmod proc_count.ko' as root - 'sudo')
2. Ensure the module has been added to the kernel (run 'lsmod | grep proc_count' -> should display the module 'proc_count')

This should create a file '/prroc/count' such that 'cat /proc/count' should display the number of currently running processes (followed by a new line).

## Cleaning Up

Explain how to remove your kernel module and clean up the code

1. Remove the module (run 'rmmod proc_count' aas root - 'sudo')
2. Ensure the module has been removed from the kernel ('lsmod | grep proc_count' should display nothing)
3. Ensure the file has been removed ('cat /proc/count' sshould throw an error that no such file exists)
4. Clean the source repo (run 'make clean')

## Testing

Report which kernel release version you tested your module on
(hint: use `uname`, check for options with `man uname`).
It should match release numbers as seen on https://www.kernel.org/.

Running on a distribution release (Arch Linux)
The release version given by 'uname -r':
5.14.8-arch1-1

