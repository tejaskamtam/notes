#include <linux/module.h>
#include <linux/printk.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include <linux/sched.h>

static int count(struct seq_file *s, void *v)
{
	struct task_struct *task;
	int count = 0;
	for_each_process(task)
	{
		count++;
	}
	seq_printf(s, "%d\n", count);
	return 0;
}
static struct proc_dir_entry *entry;

static int __init proc_count_init(void)
{
	entry = proc_create_single("count", 0, NULL, count);
	pr_info("proc_count: init\n");
	return 0;
}

static void __exit proc_count_exit(void)
{
	proc_remove(entry);
	pr_info("proc_count: exit\n");
}

module_init(proc_count_init);
module_exit(proc_count_exit);

MODULE_AUTHOR("Tejas Kamtam");
MODULE_DESCRIPTION("Dsiplay current number of running processes.");
MODULE_LICENSE("GPL");
