## UID: 305749402
(IMPORTANT: Only replace the above numbers with your true UID, do not modify spacing and newlines, otherwise your tarfile might not be created correctly)

## Pipe Up

A program written in C to reconstruct the pipe ("|") IPC tool as an excutable.

## Building

You can build the program by simply running 'make' in the terminal while in the project repo.

## Running

Some example commands and outputs are shown below:
+ `./pipe ls`
  + return: 0
  + output: equivalent to `ls`
+ `./pipe ls cat`
  + return: 0
  + output: equivalent to `ls | cat`
+ `./pipe ls bogus`
  + return: non-zero
  + output: equivalent to `bogus`
+ `./pipe ls bogus cat` 
  + return: 0
  + output: equivalent to `ls | bogus | cat`

## Cleaning up

You can clan up all binaries by running 'make clean' while in the project repo.
