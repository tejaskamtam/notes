#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
	// invalid arguments
	if (argc < 2)
	{
		errno = EINVAL;
		perror("pipe");
		return errno;
	}
	// single argument
	else if (argc == 2)
	{
		execlp(argv[1], argv[1], NULL);
		perror("execlp");
		return errno;
	}
	// establish pipeline
	int pipefd[2];
	if (pipe(pipefd) == -1)
	{
		perror("pipe");
		return errno;
	}
	// first child process
	pid_t spid = fork();
	if (spid == -1)
	{
		perror("fork");
		return errno;
	}
	if (spid == 0)
	{
		close(pipefd[0]);
		dup2(pipefd[1], STDOUT_FILENO);
		close(pipefd[1]);
		execlp(argv[1], argv[1], NULL);
		perror("execlp");
		return errno;
	}
	else
	{
		close(pipefd[1]);
		wait(NULL);
	}
	if (argc > 3)
	{
		// loop through arguments
		for (int arg = 2; arg < argc - 1; arg++)
		{
			// create child pipeline
			int childfd[2];
			if (pipe(childfd) == -1)
			{
				perror("pipe");
				return errno;
			}
			// fork child process
			pid_t cpid = fork();
			if (cpid == -1)
			{
				perror("fork");
				return errno;
			}
			// child process
			if (cpid == 0)
			{
				dup2(pipefd[0], STDIN_FILENO);
				close(pipefd[0]);
				dup2(childfd[1], STDOUT_FILENO);
				close(childfd[1]);
				close(childfd[0]);
				execlp(argv[arg], argv[arg], NULL);
				perror("execlp");
				return errno;
			}
			// parent process
			else
			{
				close(pipefd[0]);
				close(childfd[1]);
				wait(NULL);
			}
			// update pipe
			pipefd[0] = childfd[0];
		}
	}
	// last child process
	int status;
	pid_t fpid = fork();
	if (fpid == -1)
	{
		perror("fork");
		return errno;
	}
	if (fpid == 0)
	{
		dup2(pipefd[0], STDIN_FILENO);
		close(pipefd[0]);
		execlp(argv[argc - 1], argv[argc - 1], NULL);
		perror("execlp");
		return errno;
	}
	else
	{
		close(pipefd[0]);
		waitpid(fpid, &status, 0);
		if (status)
			return ECHILD;
	}
	return 0;
}
