# You Spin Me Round Robin

## Building
Run `make`

## Running
The format is:
`./rr 'file:[processes]' 'int:[quantum]'`

## Cleaning up
Run `make clean`