## UID: 305749402
(IMPORTANT: Only replace the above numbers with your true UID, do not modify spacing and newlines, otherwise your tarfile might not be created correctly)

# Hash Hash Hash

A thread-safe implementation of the singly-linked list hashmap.

## Building

Build using `make` within the project directory.

## Running

An example run that executes the base hashmap (sequential) in 1-2 seconds:
```
./hash-table-tester -t 8 -s 50000
```


## First Implementation

The v1 implementation adds a sing mutex property (variable) to the hash table struct.
This mutex is initialized is nitialized druing hash-table creation and destroyed during cleanup.
The mutex enables a lock as soon as the program encounters the "add_entry" function.
The mutex disables the lock when:
  1. if the list entry is not null -> right after updating the value.
  2. if the list entry is empty -> after inserting the key-value pair into the head of the list.

This works because the lock plaacement allows all threads to concurrently until an update to the hashmap is necessary,
so it prevents concurrent threads in the critical section of actually updating or inserting the data.
This means that the threads are allowed to perform all other functins in prallel but only update th hash table in series.
Thus, there are no race condition issues since th critical section is handled atomically and in series for each iteration.

### Performance

With 8 threads at 50,000 entries:
+ The base hashmap runs at about 1.2 - 1.5 seconds.
+ The v1 implementation runs at about 1.5 - 2.9 seconds.

With 4 threads at 100,000 entries:
+ The base hashmap runs at about 1.0 - 1.1 seconds.
+ The v1 implementation runs at about 2.0 - 2.1 seconds.

This actually causes a **performance drop** due to the program preventing all other threads from
executing any code in the add_entry function. This means each thrad must look up its position in series
for each call to add_entry and any other steps prior to actually updating the values.
Thus, the performance with the single mutex could be considerably increasd by locking the program AFTER
a thread looks up its position (bucket) and before actually updating the list values in the bucket.


## Second Implementation

The v2 implementation creates a mutex for each bucket in the hashmap.
This allows only the necessary threads to lock at a given time.
This is implemented by simply creating a mutex object in each entry of the hashmap.
Once initialized, the mutex correponding to the bucket selected by the add function
will activate a lock to allow the actual hashmap updates to take place atomically.
Once this is completed, the critical section is unlocked.
During cleanup, the mutx for each bucket is destroyed.
This works because it reaches the sweet spot of lock granularity such that
as much work asspossible is done in paraallel and locks are only implemented
when there is an actual update/edit that would cause a race condition.

### Performance

Run the tester such that the base hash table completes in 1-2 seconds.
Report the relative speedup with number of threads equal to the number of
physical cores on your machine (at least 4). Note again that the amount of work
(`-t` times `-s`) should remain constant. Report the speedup relative to the
base hash table implementation. Explain the difference between this
implementation and your first, which respect why you get a performance increase.

With 8 threads at 50,000 entries:
+ The base hashmap runs at about 1.0 - 1.5 seconds.
+ The v2 implementation runs at about 0.3 - 0.5 seconds.

With 4 threads at 100,000 entries:
+ The base hashmap runs at about 1.2 - 1.4 seconds.
+ The v2 implementation runs at about 0.35 - 0.45 seconds.

This is about a **2.8x - 3.2x performance boost** compared to base. 

The v1 implementation created only 1 mutex for the entire hashmp, so a lock was activated
any time any one thread reached the add_entry function.
The v2 implementation, on the other hand, creates a mutex for each bucket so the lock activates only when
the thread for that bucket wants to update its list. This means that all other bucket updates occur in parallel
and increase the efficiency of the program.

## Cleaning up

Simply run `make clean` in the project repo.
