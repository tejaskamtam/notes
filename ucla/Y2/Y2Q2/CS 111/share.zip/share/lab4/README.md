## UID: 305749402

(IMPORTANT: Only replace the above numbers with your true UID, do not modify spacing and newlines, otherwise your tarfile might not be created correctly)

# Hey! I'm Filing Here

An implementation of the EXT2 file system which includes a mount with a few basic dirctories, files, and links.

## Building

Simply run `make`.

## Running

To compile (after building):

1. Run `./ext2-create` - this will create the image
2. Mount the image:
   1. Make a mounting directory. For example: `mkdir mnt`
   2. Mount the file system: `sudo mount -o loop cs111 -base.img mnt`
3. The setup is complete. The command `ls -ain mnt` should output ssomething like:
```
total 3
 2 drwxr-xr-x 3    0    0 1024 Mar 18 16:23 .
54 drwxrwx--- 1    0  109  544 Mar 18 16:23 ..
13 lrw-r--r-- 1 1000 1000   11 Mar 18 16:23 hello -> hello-world
12 -rw-r--r-- 1 1000 1000   12 Mar 18 16:23 hello-world
11 drwxr-xr-x 2    0    0 1024 Mar 18 16:23 lost+found
```

## Cleaning up

To clean up:

1. Firt unmount the file system directory: `sudo umount mnt`
2. Delete the file system directory: `rmdir mnt`
3. Clean the build: `make clean`
